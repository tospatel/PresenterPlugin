package presenter.shared;

public interface AppConstant {
	String folderTextFieldName = "checkFolderForFile";
	String tempProjectName = "whstemp";
}
