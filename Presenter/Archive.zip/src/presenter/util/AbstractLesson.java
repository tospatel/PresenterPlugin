package presenter.util;

import java.io.File;


public class AbstractLesson {
public static void main(String[] args) {
	
}

public void listDirectory(String dirPath, int level) {
	File dir = new File(dirPath);
	File[] firstLevelFiles = dir.listFiles();
	if (firstLevelFiles != null && firstLevelFiles.length > 0) {
		for (File aFile : firstLevelFiles) {
			for (int i = 0; i < level; i++) {
				System.out.print("\t");
			}
			if (aFile.isDirectory()) {
				System.out.println("[" + aFile.getName() + "]");
				listDirectory(aFile.getAbsolutePath(), level + 1);
			} else {
				System.out.println(aFile.getName());
			}
		}
	}
}
}
